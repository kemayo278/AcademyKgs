import Register from "@/components/Auth/Register/RegisterForm";

export default async function RegisterPage() {
  return <Register />;
}