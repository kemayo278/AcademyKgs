import Login from "@/components/Auth/Login/LoginForm";

export default function LoginPage() {
  return <Login />;
}